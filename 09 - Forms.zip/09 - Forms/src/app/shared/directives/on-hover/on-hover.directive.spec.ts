import { OnHoverDirective } from './on-hover.directive';

describe('OnHoverDirective', () => {
  it('should create an instance', () => {
    const directive = new OnHoverDirective();
    expect(directive).toBeTruthy();
  });
});
