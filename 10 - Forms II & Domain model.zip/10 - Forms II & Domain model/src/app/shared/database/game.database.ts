import { Game } from '../models/game.model';

export const GAMES: Game[] = [
    {
        id: '1',
        title: 'World of Warcraft',
        description: 'Make love not warcraft',
    },
    {
        id: '2',
        title: 'Solitaire',
        description: 'Boring',
    }
];
