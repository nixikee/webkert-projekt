export const environment = {
  firebaseConfig: {
    /* CONFIGS COME HERE... */
  },
  production: false
};
